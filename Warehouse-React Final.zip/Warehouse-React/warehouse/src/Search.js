import React from "react";
import SearchForm from "./SearchForm";
import Catalog from "./Catalog";

const Search = (props) => {
    console.log('props with single album ', props);
    return (
        <div className="container">
            <SearchForm onSubmit={props.updateSearchResults}/>
            <Catalog catalog={props.catalog} onClick={props.updateProduct}/>
        </div>
    );
};

export default Search;