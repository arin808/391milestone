import React from 'react';
import { useNavigate } from 'react-router-dom';

const OneProduct = (props) => {

    const navigate = useNavigate();
     
    const handleCancel = () => {
        navigate('/');
    }
    return (
        <div className='container'>
                <div className='card'>
                    <h2>Product Details</h2>
                    <div className='card-body' >
                        <h5 className='card-title'>{props.product.name}</h5>
                        <p className='card-text'>${props.product.price}</p>
                        <p className='card-text'>In Stock: {props.product.quantity}</p>
                        <p className='card-text'>{props.product.description}</p>
                        <button onClick={(handleCancel)} type='button' className="btn btn-danger">Go Back</button>

                    </div>
                </div>
        </div>
    );
};

export default OneProduct;