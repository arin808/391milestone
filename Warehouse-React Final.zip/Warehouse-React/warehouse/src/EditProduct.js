import React, { useState } from 'react';
import dataSource from './dataSource';
import {useNavigate} from 'react-router-dom';

const EditProduct = (props) => {
    console.log(props.product);
    let product = {
        name: '',
        price: '',
        quantity: '',
        description: '',
    };

    let newProductCreation = true;

    if (props.product) {
        console.log('product id is ' + props.prodId)
        product = props.product;
        newProductCreation = false;
    }

    const [name, setName] = useState('');
    const [price, setPrice] = useState('');
    const [quantity, setQuantity] = useState('');
    const [description, setDescription] = useState('');
    const navigate = useNavigate();

    const updateName = (event) => {
        setName(event.target.value);
    };

    const updatePrice = (event) => {
        setPrice(event.target.value);
    };

    const updateQuantity = (event) => {
        setQuantity(event.target.value);
    };
    
    const updateDescription = (event) => {
        setDescription(event.target.value);
    };

    const handleFormSubmit = (event) => {
        event.preventDefault();

        console.log('submit');
        const editedProduct = {
            id: product.id,
            name: name,
            price: price,
            quantity: quantity,
            description: description,
        };
        console.log(editedProduct);
        
        saveProduct(editedProduct);
    };
    
    const saveProduct = async (product) => {
        let response;
        console.log("product being updated: " + product.prodId)
        if(newProductCreation)
        {
            response = await dataSource.post('/inventory', product);
        }
        else
        {
            response = await dataSource.put('/inventory', product);
        }
        console.log(response);
        console.log(response.data);
        props.onEditProduct(navigate);
    };

    const handleCancel = () => {
        navigate('/');
    };

    return (
        <div className='container'>
            <form onSubmit={handleFormSubmit}>
                <h1>{newProductCreation ? "Create New": "Edit"} Product</h1>
                <div className='form-group'>
                    <label htmlFor='name'>Product Name</label>
                    <input type='text' className='form-control' id='name' placeholder={newProductCreation ? 'Enter Product Name': product.name} value={name} onChange={updateName}/>
                    <label htmlFor='price'>Price</label>
                    <input type='number' className='form-control' id='price' placeholder={newProductCreation ? 'Enter Product Price': product.price} value={price} onChange={updatePrice}/>
                    <label htmlFor='quantity'>Quantity</label>
                    <input type='number' className='form-control' id='quantity' placeholder={newProductCreation ? 'Enter Number in Stock': product.quantity} value={quantity} onChange={updateQuantity}/>
                    <label htmlFor='description'>Description</label>
                    <textarea type='text' className='form-control' id='description' placeholder={newProductCreation ? 'Enter Product Description': product.description} value={description} onChange={updateDescription}/>
                </div>
                <br/>
                <div align="center">
                    <button type='button' className='btn btn-light' onClick={handleCancel}>Cancel</button>
                    <button type="submit" className='btn btn-primary'>Submit</button>
                </div>
            </form>
        </div>
    );
};

export default EditProduct;