import React from 'react';
import { useNavigate } from 'react-router-dom';
import dataSource from './dataSource';

const Card = (props) => {
    const navigate = useNavigate();

    const handleButtonClick = (event, uri) => {
        console.log('ID clicked is ' + props.prodId);
        props.onClick(props.prodId, uri);
    };

    const onDeleteProduct = async (prodId, uri) => {
        let response; 
        console.log("deleting product with ID of: " + prodId);
        response = await dataSource.delete('/inventory/'+ prodId);
        console.log(response);
        console.log(response.data);
        props.onDeleteProduct(navigate);
    }

    return (
        <div className="card" style={{width: '18rem'}}>
            <div className="card-body">
                <h5 className="card-title">{ props.name }</h5>
                <p className="card-text">${ props.price }</p>
                <button onClick={() => handleButtonClick(props.prodId, '/show/')} className="btn btn-success">
                    { props.buttonText }
                </button>
                <button onClick={() => handleButtonClick(props.prodId, '/edit/')} className="btn btn-primary">
                    Edit
                </button>
                <button onClick={() => onDeleteProduct(props.prodId, '/')} className="btn btn-danger">
                    Delete
                </button>
            </div>
        </div>
    );
};

export default Card;