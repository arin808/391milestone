import React from "react";
import Card from './Card';
import { useNavigate } from "react-router-dom";

const Catalog = (props) => {
    const handleSelectionOne = (prodId, uri) => {
        console.log('Selected ID is ' + prodId);
        props.onClick(prodId, navigator, uri);
    };

    console.log('props catalog ', props);
    const navigator = useNavigate();
    const inventory = props.catalog.map((product) => {
        return (
            <Card 
                key={product.id} 
                prodId={product.id}
                name={product.name} 
                price={product.price}
                buttonText='View' 
                onClick={handleSelectionOne}
            />
        );
    });
    return <div className='container'>{inventory}</div>
};

export default Catalog;