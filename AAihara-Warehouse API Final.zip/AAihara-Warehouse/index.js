// Application Dependencies
const { Product } = require('./lib/app/images/models/Product');
const { InventoryDAO } = require('./lib/app/images/database/InventoryDAO.js')

const bodyParser = require('body-parser');

// Create instance of an Express Application on Port 3000
const express = require('express');
const app = express();
const port = 5000;
const cors = require('cors');
app.use(cors());

// Database configuration
const dbHost = "localhost"
const dbPort = 3306;
const dbUsername = "root"
const dbPassword = "root"

// Set location of static resources and use the JSON body parser
app.use(express.static('app/images'))
app.use(bodyParser.json());

// Route code begins
// GET Route at Root '/' that returns a Test Text message
app.get('/', function (_req, res)
{
    // Return Test Text
    console.log('In GET / Route');
    res.send('This is the default root Route.');
})
// GET Route at '/inventory' that returns all Products from the database
app.get('/inventory', function (_req, res)
{
    // Return Artists List as JSON, call InventoryDAO.findAllProducts, and return JSON array of Products
    console.log('In GET /inventory Route');
    let dao = new InventoryDAO(dbHost, dbPort, dbUsername, dbPassword);
    dao.findAllProducts(function(products)
    {
        res.json(products);
    });
})


// GET Route at '/inventory/:id' that returns a Product given an ID from the database
app.get('/inventory/:id', function (req, res)
{
    // Get the Product
    console.log('In GET /inventory Route with ID of ' + req.params.id);
    let id = Number(req.params.id);
 
    // Call InventoryDAO.findById() to find Product from the database and return it
    let dao = new InventoryDAO(dbHost, dbPort, dbUsername, dbPassword);
    dao.findById(id, function(product)
    {
        console.log(product)
        if(product == null)
            res.status(200).json({"error" : "Invalid Product ID"})
        else
            res.status(200).json(product)
    });
 })


// GET Route at '/inventory/description/:search' that does a wildcard search for all Products searching by Description from the database
app.get('/inventory/description/:search', function (req, res)
{
    // Return Products List as JSON, call InventoryDAO.findByDescription(), and return JSON array of Products
    console.log('In GET /inventory/description Route for ' + req.params.search);
    let dao = new InventoryDAO(dbHost, dbPort, dbUsername, dbPassword);
    dao.findByDescription(req.params.search, function(products)
    {
        res.json(products);
    });
})

// POST Route at '/inventory' that adds a Product the database
app.post('/inventory', function (req, res)
{
    //console.log(req);
    
    // If invalid POST Body then return 400 response else add Product to the database
    console.log('In POST /inventory Route with Post of ' + JSON.stringify(req.body));
    if(!req.body.name && false)
    {
        // Check for valid POST Body, note this should validate EVERY field of the POST
        res.status(400).json({error: "Invalid Product Posted"});
    }
    else
    {
        // Create a Product object model from Posted Data
        let product = new Product(req.body.id, req.body.name, req.body.price, req.body.quantity, req.body.description);

        // Call InventoryDAO.create() to create an Product from Posted Data and return an OK response     
        let dao = new InventoryDAO(dbHost, dbPort, dbUsername, dbPassword);
        dao.create(product, function(id)
        {
            if(id == -1)
                res.status(200).json({"error" : "Creating Product failed"})
            else
                res.status(200).json({"success" : "Creating Product passed with an Product ID of " + id});
        });     
      }
})

// PUT Route at '/inventory' that updates an Product in the database
app.put('/inventory', function (req, res)
{
    // If invalid PUT Body then return 400 response else update Product to the database
    console.log('In PUT /inventory Route with Post of ' + JSON.stringify(req.body));
    if(!req.body.name && false)
    {
        // Check for valid PUT Body, note this should validate EVERY field of the POST
        res.status(400).json({error: "Invalid Product Posted"});
    }
    else
    {
        // Create a Product object model from Posted Data
        let product = new Product(req.body.id, req.body.name, req.body.price, req.body.quantity, req.body.description);

        // Call InventoryDAO.update() to update an Product from Posted Data and return an OK response     
        let dao = new InventoryDAO(dbHost, dbPort, dbUsername, dbPassword);
        dao.update(product, function(changes)
        {
            if(changes == 0)
                res.status(200).json({"error" : "Updating Product passed but nothing was changed"})
            else
                res.status(200).json({"success" : "Updating Product passed and data was changed"});
        });     
    }
})

// DELETE Route at '/inventory/:id' that deletes an Product given an ID from the database
app.delete('/inventory/:id', function (req, res)
{
    // Get the Product
    console.log('In DELETE /inventory Route with ID of ' + req.params.id);
    let id = Number(req.params.id);
 
    // Call InventoryDAO.delete() to delete a Product from the database and return if passed
    let dao = new InventoryDAO(dbHost, dbPort, dbUsername, dbPassword);
    dao.delete(id, function(changes)
    {
        if(changes == 0)
            res.status(200).json({"error" : "Delete Product failed"})
        else
            res.status(200).json({"success" : "Delete Product passed"})
    });
})

// Route code ends
// Start the Server
app.listen(port, () => 
{
    console.log(`Example app listening on port ${port}!`);
});
