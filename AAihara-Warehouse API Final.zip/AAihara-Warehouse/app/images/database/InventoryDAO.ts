import { Product } from "../models/Product";
import * as util from "util";
import * as mysql from "mysql";

export class InventoryDAO
{
    private host:string = "";
    private port:number = 3306;
    private username:string = "";
    private password:string = "";
    private schema:string = "warehouse391";
    private pool = this.initDbConnection();
    
    /**
     * Non-default constructor.
     * 
     * @param host Database Hostname
     * @param username Database Username
     * @param password Database Password
     */
    constructor(host:string, port:number, username:string, password:string)
    {
        // Set all class properties
        this.host = host;
        this.port = port;
        this.username = username;
        this.password = password;
        this.pool = this.initDbConnection();
    }

   /**
     * CRUD method to return all Products.
     * 
     * @param callback Callback function with an Array of type Product.
     */
    public findAllProducts(callback: any)
    {
        // List of Products to return
        let products:Product[] = [];
        
        // Get a pooled connection to the database, run the query to get all the Products
        this.pool.getConnection(function(err:any, connection:any)
        {
            // Throw error if an error
            if (err) throw err

            // Run query    
            connection.query('SELECT * FROM INVENTORY', function (err:any, rows:any, fields:any) 
            {
                // Release connection in the pool
                connection.release();

                // Throw error if an error
                if (err) throw err
    
                // Loop over result set and save the Product 
                for(let x=0;x < rows.length;++x)
                {
                    products.push(new Product(rows[x].id, rows[x].name, rows[x].price, rows[x].quantity, rows[x].description));
                }
    
                // Do a callback to return the results
                callback(products);
            });
    
        });
     } 

    /**
     * CRUD method to searches for a Product by an id
     * 
     * @param search wildcard  to search Products for.
     * @param callback Callback function with an Array of type Product.
     */
    public findById(search:string, callback: any)
    {
         // List of Products to return
         let products:Product[] = [];

        // Get pooled database connection and run queries   
        this.pool.getConnection(async function(err:any, connection:any)
        {
            // Release connection in the pool
            connection.release();

            // Throw error if an error
            if (err) throw err;

            // Use Promisfy Util to make an async function and run query to get all Products for search partial
            connection.query = util.promisify(connection.query);
            let rows = await connection.query("SELECT * FROM INVENTORY WHERE id = ?", [search]);
            for(let x=0;x < rows.length;++x)
            {
                // Add Product to the list
                products.push(new Product(rows[x].id, rows[x].name, rows[x].price, rows[x].quantity, rows[x].description));
            }
            // Do a callback to return the results
            callback(products);
         });
    }  

    /**
     * CRUD method to searches for all Products by a wildcard serach in Description.
     * 
     * @param search wildcard Description to search Products for.
     * @param callback Callback function with an Array of type Product.
     */
    
    public findByDescription(search:string, callback: any)
    {
         // List of Products to return
         let products:Product[] = [];

        // Get pooled database connection and run queries   
        this.pool.getConnection(async function(err:any, connection:any)
        {
            // Release connection in the pool
            connection.release();

            // Throw error if an error
            if (err) throw err;

            // Use Promisfy Util to make an async function and run query to get all Products for search partial
            connection.query = util.promisify(connection.query);
            let rows = await connection.query("SELECT * FROM INVENTORY WHERE description LIKE ?", ['%' + search + '%']);
            for(let x=0;x < rows.length;++x)
            {
                // Add Product and its Tracks to the list
                products.push(new Product(rows[x].id, rows[x].name, rows[x].price, rows[x].quantity, rows[x].description));
            }

            // Do a callback to return the results
            callback(products);
         });
    }            

    /**
     * CRUD method to create an Product.
     * 
     * @param product Product to insert.
     * @param callback Callback function with -1 if an error else Product id created.  
     */
    public create(product:Product, callback: any)
    {
        // Get pooled database connection and run queries   
        this.pool.getConnection(async function(err:any, connection:any)
        {
            // Release connection in the pool
            connection.release();

            // Throw error if an error
            if (err) throw err;

            // Use Promisfy Util to make an async function and insert Product
            connection.query = util.promisify(connection.query);
            let result1 = await connection.query('INSERT INTO INVENTORY (id, name, price, quantity, description) VALUES(?,?,?,?,?)', [product.Id, product.Name, product.Price, product.Quantity, product.Description]);
            console.log(product);
            if(result1.affectedRows != 1)
               callback(-1);

            // Use Promisfy Util to make an async function and run query to insert all Tracks for this Product
            let id = result1.insertId;

            // Do a callback to return the results
            callback(id);
        });
    }

    /**
     * CRUD method to update an Product.
     * 
     * @param product Product to update.
     * @param callback Callback function with number of rows updated.  
     */
    public update(product:Product, callback: any)
    {
        // Get pooled database connection and run queries   
        this.pool.getConnection(async function(err:any, connection:any)
        {
            // Release connection in the pool
            connection.release();
 
            // Throw error if an error
            if (err) throw err;
 
            // Use Promisfy Util to make an async function and update Product
            let changes = 0;
            connection.query = util.promisify(connection.query);
            let result1 = await connection.query('UPDATE INVENTORY SET name=?, price=?, quantity=?, description=? WHERE id=?', [product.Name, product.Price, product.Quantity, product.Description, product.Id]);
            if(result1.changedRows != 0)
                ++changes;
 
            // Do a callback to return the results
            callback(changes);
        });
     }

     /**
     * CRUD method to delete an Product.
     * 
     * @param product Product id to delete.
     * @param callback Callback function with number of rows deleted.  
     * */
    public delete(id:number, callback: any)
    {
        // Get pooled database connection and run queries   
        this.pool.getConnection(async function(err:any, connection:any)
        {
            // Release connection in the pool
            connection.release();

            // Throw error if an error
           if (err) throw err;

            // Use Promisfy Util to make an async function and run query to delete the tracks for an Product
            let changes = 0;
            connection.query = util.promisify(connection.query);
            let result1 = await connection.query('DELETE FROM INVENTORY WHERE id=?', [id]);
            changes = changes + result1.affectedRows;

            // Do a callback to return the results
            callback(changes);
        });
    }

    //* **************** Private Helper Methods **************** */

    /**
     * Private helper method to initialie a Database Connection
     */
    private initDbConnection():any
    {
        return mysql.createPool({host: this.host, port: this.port, user: this.username, password: this.password, database: this.schema, connectionLimit: 10});
    }
}
