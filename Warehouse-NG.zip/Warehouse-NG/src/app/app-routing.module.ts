import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AllWarehouseComponent } from './all-warehouse/all-warehouse.component';
import { CreateProductComponent } from './create-product/create-product.component';
import { DisplayProductComponent } from './display-product/display-product.component';
import { EditProductComponent } from './edit-product/edit-product.component';

const routes: Routes = [
  {path: 'create', component: CreateProductComponent},
  {path: 'edit/:id', component: EditProductComponent},
  {path: 'display', component: DisplayProductComponent},
  {path: 'warehouse', component: AllWarehouseComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
