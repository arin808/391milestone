import { Component, Input, OnInit } from '@angular/core';
import { Product } from '../models/Product';
import { WarehouseServiceService } from '../services/warehouse-service.service';

@Component({
  selector: 'app-display-product',
  templateUrl: './display-product.component.html',
  styleUrls: ['./display-product.component.css']
})
export class DisplayProductComponent implements OnInit {

  @Input() product:Product;
  
  constructor(private service: WarehouseServiceService) { }

  ngOnInit(): void {
  }

  //Delete confirmation
  onConfirm()
  {
    var confirmation = confirm("Are you sure you want to delete this product?");
    if(confirmation)
    {
      console.log(this.product);
      this.service.deleteProduct(this.product.Id, (success:string)=>
      {
        console.log("Product with ID of " + this.product.Id + " deleted.");
      })
    }
  }
}
