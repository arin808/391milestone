import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllWarehouseComponent } from './all-warehouse.component';

describe('AllWarehouseComponent', () => {
  let component: AllWarehouseComponent;
  let fixture: ComponentFixture<AllWarehouseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AllWarehouseComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AllWarehouseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
