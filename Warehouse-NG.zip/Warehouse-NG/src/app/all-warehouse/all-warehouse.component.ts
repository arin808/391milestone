import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Product } from '../models/Product';
import { WarehouseServiceService } from '../services/warehouse-service.service';

@Component({
  selector: 'app-all-warehouse',
  templateUrl: './all-warehouse.component.html',
  styleUrls: ['./all-warehouse.component.css']
})
export class AllWarehouseComponent implements OnInit {

  selectedProduct: Product;
  products: Product[];

  constructor(private route: ActivatedRoute, private service: WarehouseServiceService) { }

  public onSelectProduct(product:Product)
  {
    this.selectedProduct = product;
  }

  ngOnInit()
  {
    this.route.queryParams.subscribe(params => {
      console.log("Getting data...");
      this.service.getAllProducts((products:Product[]) => {
        this.products = products;
        this.selectedProduct = null;
      })
    })
  }

}
