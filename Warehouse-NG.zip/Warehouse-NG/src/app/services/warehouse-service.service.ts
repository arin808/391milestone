import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { response } from 'express';
import { Product } from '../models/Product';

@Injectable({providedIn: 'root'})

export class WarehouseServiceService {

  constructor(private http: HttpClient) { }

  hostname: string = "http://localhost:5000";

  public getAllProducts(callback:any)
  {
    this.http.get<Product[]>(this.hostname + "/inventory")
    .subscribe((data) => 
    {
      let products:Product[] = [];
      console.log(data);
      for(let x=0; x<data.length; ++x)
      {
        products.push(new Product(data[x]['id'], data[x]['name'],
          data[x]['price'], data[x]['quantity'], data[x]['description']));
      }
      callback(products);
    });
  }

  public getById(id:number,callback:any)
  {
    this.http.get<Product[]>(this.hostname + "/inventory/" + id)
    .subscribe((data) =>
    {
      console.log(data[0]['id'])
      let product:Product = new Product(data[0]['id'], data[0]['name'], data[0]['price'], data[0]['quantity'], data[0]['description']);
      callback(product);
    });
  }

  public getByDescription(description: string,callback:any)
  {
    this.http.get<Product>(this.hostname + "/inventory/description/" + description)
    .subscribe((data) =>
    {
      let product:Product = new Product(data.Id, data.Name, data.Price, data.Quantity, data.Description);
      callback(product);
    });
  }

  public createProduct(newProduct:Product,callback:any)
  {
    this.http.post<Product>(this.hostname + "/inventory", newProduct)
    .subscribe((data) =>
    {
      callback(data);
    });
  }

  public updateProduct(updatedProduct:Product,callback:any)
  {
    this.http.put<Product>(this.hostname + "/inventory", updatedProduct)
    .subscribe((data) =>
    {
      callback(data);
    });
  }

  public deleteProduct(id:number,callback:any)
  {
    this.http.delete<Product>(this.hostname + "/inventory/" + id)
    .subscribe((data) =>
    {
      callback(data);
    })
  }
}
