import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Product } from '../models/Product';
import {WarehouseServiceService } from '../services/warehouse-service.service'
@Component({
  selector: 'app-create-product',
  templateUrl: './create-product.component.html',
  styleUrls: ['./create-product.component.css']
})
export class CreateProductComponent implements OnInit {

  createProduct = new FormGroup({
    name: new FormControl(''),
    price: new FormControl(''),
    quantity: new FormControl(''),
    description: new FormControl('')
  })

  product: Product;

  constructor(private service: WarehouseServiceService) { }

  onCreate(data: {name: string, price: number, quantity: number, description: string})
  {
    this.product = new Product(0, data.name, data.price, data.quantity, data.description);
    console.log("Adding Product...")
    this.service.createProduct(this.product, (product:Product) =>
    {
      this.product = product
    })  
  }


  ngOnInit()
  {
  }

}
