import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Product } from '../models/Product';
import { WarehouseServiceService } from '../services/warehouse-service.service';

@Component({
  selector: 'app-edit-product',
  templateUrl: './edit-product.component.html',
  styleUrls: ['./edit-product.component.css']
})
export class EditProductComponent implements OnInit {

  constructor(private service: WarehouseServiceService, private route: ActivatedRoute) { }

  editProduct = new FormGroup({
    name: new FormControl(''),
    price: new FormControl(''),
    quantity: new FormControl(''),
    description: new FormControl('')
  });

  product: Product;
  id:number;

  ngOnInit()
  {
    this.route.paramMap.subscribe(
      params =>{
        this.id = parseInt(params.get('id'));
      }
    )

    this.service.getById(this.id, (product:Product) =>
    {
      this.product = product;
      console.log(this.product)
    });
    
  }

  onEdit(data: {name: string, price: number, quantity: number, description: string})
  {
    this.product.Name = data.name;
    this.product.Price = data.price;
    this.product.Quantity = data.quantity;
    this.product.Description = data.description;

    this.service.updateProduct(this.product, (product:Product) =>
    {
      this.product = product;
      console.log(this.product);
    })
  }
}
