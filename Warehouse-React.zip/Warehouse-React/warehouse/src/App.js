import React, { useEffect, useState } from 'react';
import { Route, Routes, BrowserRouter } from 'react-router-dom';
import dataSource from './dataSource';
import OneProduct from './OneProduct';
import EditProduct from './EditProduct';
import Search from './Search';
import NavBar from './NavBar';
import Card from './Card';
import './App.css';

const App = (props) => {  
  const [catalog, setCatalog] = useState([]);
  const [searchPhrase, setSearchPhrase] = useState('');
  const [currentlySelectedProductId, setCurrentlySelectedProductId] = useState(0);

  let refresh = false;

  const loadProducts = async () => {
    const response = await dataSource.get('/inventory');
    
    setCatalog(response.data);
  }
  
    useEffect(() => {
      loadProducts();
    }, [refresh]);
  
  const updateSearchResults = async (phrase) => {
    console.log('phrase is: ' + phrase);
    setSearchPhrase(phrase);
  };

  const updateProduct = (id, navigate, uri) => {
    console.log('Update Product = ', id);
    console.log('Update Product = ', navigate);
    var indexNumber = 0;

    for (var i = 0; i < catalog.length; ++i) {
      if (catalog[i].id === id) indexNumber = i;
    }
    setCurrentlySelectedProductId(indexNumber);
    let path = uri + id;
    console.log('path', path);
    navigate(path);
  };

  console.log('catalog', catalog);
  const renderedList = catalog.filter((product) => {
      if (product.name.toLowerCase().includes(searchPhrase.toLowerCase()) || 
          product.description.toLowerCase().includes(searchPhrase.toLowerCase()) || 
          searchPhrase === '')
      {
        return true;
      }
      return false;
    });  

  console.log('renderedList', renderedList);

  const onEditProduct = (navigate) => {
    loadProducts();
    navigate('/');
  }

  const onDeleteProduct = () => {
   loadProducts();
   //navigate('/');
  }

  return (
    <>
    <BrowserRouter>
      <NavBar/>
      <Routes>
        <Route exact path='/'element={<Search updateSearchResults={updateSearchResults} catalog={renderedList} updateProduct={updateProduct}/>}/>
        <Route exact path='/new' element={<EditProduct onEditProduct={onEditProduct}/>}/>
        <Route exact path='/edit/:prodId' element={<EditProduct onEditProduct={onEditProduct} product={catalog[currentlySelectedProductId]}/>}/>
        <Route exact path='/show/:prodId' element={<OneProduct product={catalog[currentlySelectedProductId]}/>}/>
        <Route exact path='/' element={<Card onDeleteProduct={onDeleteProduct} prodId={catalog[currentlySelectedProductId]}/>}/>
      </Routes>
    </BrowserRouter>
    </>
  );
};

export default App;